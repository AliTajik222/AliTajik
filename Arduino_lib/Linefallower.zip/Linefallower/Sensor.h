#ifndef SENSOR_H
#define SENSOR_H
#include <Arduino.h>
extern int Sensor_value_analog[8];
extern int Sensor_value_digital[8];
void SensorRead();
#endif
