#ifndef MOTOR_SPEED_H
#define MOTOR_SPEED_H
#include <Arduino.h>
void motor(int a,int b);
#endif
